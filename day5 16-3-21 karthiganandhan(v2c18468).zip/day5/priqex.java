import java.util.Iterator;
import java.util.PriorityQueue;

public class priqex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 PriorityQueue<String> pq = new PriorityQueue<>();
		 
	        pq.add("hi");
	        pq.add("queue");
	        pq.add("in java");
	        pq.add("A");
	        pq.add("z");
	        System.out.println("Final PriorityQueue - " + pq);
	        Iterator<String> iterator = pq.iterator();
	 
	        while (iterator.hasNext()) {
	            System.out.print(iterator.next() + " ");
	        }
	            pq.remove("queue");
	            
	            System.out.println("After Remove - " + pq);
	     
	            System.out.println("Poll Method - " + pq.poll());//remove head
	     pq.add("new");
	     pq.add("another");
	     System.out.println("add PriorityQueue - " + pq);
	     System.out.println("Peek Method - " +  pq.peek());//ret head
	           
	            System.out.println("Final PriorityQueue - " + pq);

	}

}

