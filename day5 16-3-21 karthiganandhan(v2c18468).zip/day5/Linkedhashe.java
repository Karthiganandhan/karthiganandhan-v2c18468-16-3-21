import java.util.LinkedHashSet;

class ex
{
	private String name;
	   private Integer id;
	   private String address;
	   private String salary;
	   public String getName() {
		return name;
	}
	public ex(String name, Integer id, String address, String salary) {
	
		this.name = name;
		this.id = id;
		this.address = address;
		this.salary = salary;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	
}
public class Linkedhashe{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet<ex> resource =  
                new LinkedHashSet<ex>();
		
	      resource.add(new ex("nandha", 1,"dindigul","10000"));
	      resource.add(new ex("surya", 2,"dindigul","15000"));
	      resource.add(new ex("surya", 2,"dindigul","15000"));
	      resource.add(new ex("siva", 3,"salem","18000"));
	      resource.add(new ex("karthi", 4,"madurai","19000"));
	      for (ex s : resource) {
	            System.out.println("name:"+s.getName());
	      System.out.println( "address:"+s.getAddress());
	      System.out.println("id:"+s.getId());
	      System.out.println("sal:"+s.getSalary()); 
	      
	      }

	}

}
